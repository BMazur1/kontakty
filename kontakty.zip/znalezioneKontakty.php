<?php
session_start();
    if (!isset($_POST['imie'])){
        header('Location: index.php');
        exit();
    }

?>


<!DOCTYPE HTML>
<html lang="pl">
<head>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="style.css">
    
<body>
<div class="global-container">
<?php
    require_once("connect.php");

    $connection = @new mysqli($host, $db_user, $db_password, $db_name);
    if($connection->connect_errno!=0){
        echo "Error:".$connection->connect_errno;
    }else{
        if(strlen($_POST['imie'])>0){
            $imie=$_POST['imie'];
            $nazwisko = "0";
            $nrTelefonu = "a";
        }elseif(strlen($_POST['nazwisko'])>0){
            $imie = "0";
            $nazwisko=$_POST['nazwisko'];
            $nrTelefonu = "a";
        }elseif(strlen($_POST['nrTelefonu'])>0){
            $imie = "0";
            $nazwisko = "0";
            $nrTelefonu=$_POST['nrTelefonu'];
        }else{
            $imie = "0";
            $nazwisko = "0";
            $nrTelefonu = "a";
            
        }
        $sql = "SELECT * FROM mojekontakty WHERE (db_imie LIKE '%$imie%') 
        OR (db_nazwisko LIKE '%$nazwisko%') 
        OR (db_numerTelefonu LIKE '%$nrTelefonu%')";

        if ($result = @$connection->query($sql)){
            $ile_kontaktow = $result->num_rows;
            if($ile_kontaktow>0){
                for($i=0; $i < $ile_kontaktow; $i++){
                $wiersz = $result->fetch_assoc();
                $db_imie = $wiersz['db_imie'];
                $db_nazwisko = $wiersz['db_nazwisko'];
                $db_nrTelefonu = $wiersz['db_numerTelefonu'];
                //echo print_r($wiersz);
                $j=$i+1;
                echo '<div class="result">';
                echo $j.'. ';
                echo 'Imię: <div class="red-result">'.$db_imie.'</div>';
                echo 'Nazwisko: <div class="red-result">'.$db_nazwisko.'</div>';
                echo 'Numer telefonu: <div class="red-result">'.$db_nrTelefonu.'</div></br>';
                echo '</div>';
                }
                echo '<form action="index.php" method="post">';
                echo '<input type="submit" value = "Powrót do strony głownej" class="btn">';
                echo '</form>';


                $result->close();


            }else{
                echo "Podany kontak nie istnieje</br>";
                echo "Chcesz spróbowac jeszcze raz czy wpisać nowy kontakt do ksiązki?</br>";
                echo '<form action="dodajKontakt.php" method="psot">';
                echo '<input type="submit" value="Dodaj nowy kontak" class="btn">';
                echo '</form>';
                echo '<form action="index.php" method="psot">';
                echo '<input type="submit" value="Spróbuj jeszcze raz" class="btn">';
                echo '</form>';

            }
        }

        $connection->close();
    }

    

?>





</div>


</body>
</head>

</html>