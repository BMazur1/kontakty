<?php
    session_start();

    if(!isset($_SESSION['udaneDodanieKonta'])){
        
    }else{
        unset($_SESSION['udaneDodanieKonta']);
        echo '<script>alert("Udane dodanie konta")</script>';

    }


?>


<!DOCTYPE HTML>
<html lang="pl">
<head>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="style.css">
    
<body>
    <div class="global-container">
        <h2>Witaj na stronie</br>
        Wpisz znane Ci dane kontaktu:</h2></br>

        
    <form action="znalezioneKontakty.php" method="post">
        <div class="input-box">
            <label>Imię:</label> <input type="text" name="imie"/> </br>
        </div>
        <div class="input-box">
            <label>Nazwisko:</label> <input type="text" name="nazwisko"/></br>
        </div>
        <div class="input-box">
            <label>Numer telefonu: </label><input type="text" name="nrTelefonu"/></br>
        </div>
            <input type="submit" value="Sprawdź kontakt" class="btn">
            <input type="submit" value="Dodaj nowy kontak" class="btn" formaction="dodajKontakt.php">
    </form>
        
    </div>


<?php

?>

</body>
</head>

</html>