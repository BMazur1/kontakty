<?php


?>


<!DOCTYPE HTML>
<html lang="pl">
<head>
    <meta charset="utf-8"/>
<body>
    Kontakt dodany prawidłowo </br>
    Kliknji aby powrócic do strony startowej</br>

    <form action="znalezioneKontakty.php" method="post">
        <input type="submit" value="Sprawdź kontakt">
    </form>
    <form action="dodajKontakt.php" method="psot">
        <input type="submit" value="Dodaj nowy kontak">
    </form>


<?php

?>

</body>
</head>

</html>